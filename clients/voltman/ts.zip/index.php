<html>

<head>
<!--  developed by Gideon Oelofse-->
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Voltman Electrical Contractors</title>
<meta content="7a6il2jZiiDQ2lwH0jTZGdR2L1ZN8CJ5ParXYYcemgg" name="google-site-verification">
<!-- Jacques 2012/04/05 -->
<meta content="ZA-GT" name="geo.region">
<meta content="Electrical Maintenance" name="Classification">
<meta content="Voltman is a small electrical company that provide proffessional Industrial and domestic electrical services to gauteng that require a electrician" name="description">
<meta content="COC electrician , domestic electrician , electrical contractor , electrical expert , electrical maintenance , electrical repairs , electrical services , electrician , electrician alberton , electrician benoni , electrician boksburg , electrician centurion , electrician east rand , electrician edenvale , electrician gauteng , electrician germiston , electrician kyalami , electrician pretoria , electrician randburg , electrician sandton , general electrician , industrial electrician , specialised electrician , swimming pool electrician , swimming pool pump electrician , " name="keywords">
<style type="text/css">
.style1 {
	border-collapse: collapse;
}
.auto-style1 {
	background-color: #A9CF46;
}
.auto-style2 {
	background-color: #75A34B;
}
.auto-style3 {
	background-color: #28272F;
}
.auto-style4 {
	line-height: 150%;
	text-align: justify;
}
.auto-style5 {
	font-family: Arial;
	font-size: 10pt;
}
.auto-style6 {
	font-family: Arial;
	font-size: 11pt;
}
.auto-style7 {
	text-align: center;
}
.auto-style9 {
	border-style: groove;
	border-width: 3px;
}
.auto-style10 {
	font-family: Arial;
	font-size: 10pt;
	color: #FFFFFF;
}
.auto-style11 {
	font-family: Arial;
	font-size: 11pt;
	color: #FFFFFF;
}
.auto-style12 {
	text-align: right;
	font-family: Arial;
	font-size: 10pt;
	color: #FFFFFF;
}
.auto-style13 {
	border-width: 0px;
}
.auto-style14 {
	text-decoration: none;
}
.auto-style15 {
	color: #FFFFFF;
}
.auto-style16 {
	text-align: left;
}
</style>
<!-- Jacques 2012/04/05 -->
<script type="text/javascript">   
var _gaq = _gaq || [];  _gaq.push(['_setAccount', 'UA-29557310-1']);  _gaq.push(['_trackPageview']);  (function() {    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);  })();</script>
</head>

<body style="margin-top: 0; background-image: url('images/back.jpg'); background-attachment: fixed;">
<?php include('mailer.php');?>
<div align="center">
	<table id="table1" border="0" cellpadding="0" class="style1" style="width: 962;">
		<tr>
			<td>
			<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
				<tr>
					<td valign="top">
					<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
						<tr>
							<td>
							<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
								<tr>
									<td class="auto-style16" valign="top">
									<img alt="Voltman Electrical Electrician Gauteng" height="127" src="logo_top.jpg" width="622"></td>
									<td style="width: 106; height: 127">
									<a href="?#home" onmouseout="menu1.src='home1.jpg'   ; return true;" onmouseover="menu1.src='home2.jpg'   ; return true;">
									<img alt="About us" class="auto-style13" height="127" name="menu1" src="home1.jpg" width="106"></a></td>
									<td style="width: 91; height: 127">
									<a href="?#blog" onmouseout="menu2.src='blog1.jpg'   ; return true;" onmouseover="menu2.src='blog2.jpg'   ; return true;">
									<img align="top" alt="Our Blog - Coming soon!" class="auto-style13" height="127" name="menu2" src="blog1.jpg" width="91"></a></td>
									<td style="width: 124; height: 127">
									<a href="?#contact" onmouseout="menu3.src='cont1.jpg'   ; return true;" onmouseover="menu3.src='cont2.jpg'   ; return true;">
									<img align="top" alt="Our Contact Details" class="auto-style13" height="127" name="menu3" src="cont1.jpg" width="124"></a></td>
								</tr>
							</table>
							</td>
						</tr>
						<tr>
							<td>
							<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
								<tr>
									<td style="width: 623; height: 20">
									<img height="20" src="bar_green.jpg" width="623"></td>
									<td style="width: 320; height: 20">
									<img height="20" src="bar_black.jpg" width="320"></td>
								</tr>
							</table>
							</td>
						</tr>
					</table>
					</td>
					<td style="width: 18; height: 147">
					<img align="top" height="147" src="righttab.jpg" width="18"></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td valign="top">
			<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
				<tr>
					<td style="width: 623" valign="top">
					<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
						<tr>
							<td class="auto-style1" valign="top">
							<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
								<tr>
									<td style="width: 20">&nbsp;</td>
									<td style="width: 282" valign="top">
									<h2><br><a name="home">
									<img align="top" alt="Voltman Electrical" height="24" src="welcome_head.jpg" width="95"></a></h2>
									<p class="auto-style4">
									<span class="auto-style5">Welcome and thank 
									you for visiting the <strong>VOLTMAN</strong> 
									website. We are a small <strong>electrical company</strong> 
									that provide <strong>Industrial and Domestic 
									electrical services</strong> to our immediate 
									and neighbouring cities.</span><br class="auto-style5">
									<span class="auto-style5">Based on the East 
									Rand we operate mainly on the Greater East Rand 
									and all surrounding areas including but not 
									limited to, the following; Kempton Park, Isando, 
									Spartan, Jet Park, Kew, Boksburg, Bredell, Petit, 
									Centurion, PTA, Benoni, Edenvale, Midrand, Dainfern, 
									Kyalami, Woodmead, Meyerton, Alberton and beyond!</span><br class="auto-style5">
									<span class="auto-style6"><em>In short</em></span><span class="auto-style5">... 
									-<strong> GAUTENG</strong> and Further.</span></p>
									<h2><span class="auto-style5">
									<img align="top" alt="General Electrical Services Sandton" height="17" src="gen_head.jpg" width="131"></span></h2>
									<p class="auto-style4">
									<span class="auto-style5">&nbsp; • Certificates 
									(COC)<br>&nbsp; • Testing<br>&nbsp; • Trouble 
									Shooting<br>&nbsp; • Suggestive Guidance<br>&nbsp; 
									• Pool Pumps Motors &amp; DB&#39;s<br>&nbsp; 
									• Jacuzzi Pumps &amp; Switches<br>&nbsp; • Special 
									Services<br>&nbsp; • Stand-By on Request &amp;<br>&nbsp; 
									• Contracting Support</span></p>
									<h2><span class="auto-style5">
									<img align="top" alt="Domestic Electrical Services Gauteng" height="17" src="dom_head.jpg" width="138"></span></h2>
									<p class="auto-style4">
									<span class="auto-style5"><strong>Dwellings 
									- General</strong><br>&nbsp; • Flats and Flatlets<br>&nbsp; 
									• Houses<br>&nbsp; • Town Houses<br>&nbsp; • 
									Out Buildings<br>&nbsp; • Garages&nbsp;&nbsp;&nbsp; 
									...and more<br>&nbsp;</span></p>
									</td>
									<td style="width: 20" valign="top">&nbsp;</td>
									<td style="width: 282" valign="top">
									<h2><span class="auto-style5"><br><br>
									<img alt="Specialised Electrical Services Gauteng" height="17" src="spec_head.jpg" width="151"></span></h2>
									<p class="auto-style4">
									<span class="auto-style5">&nbsp; • Distribution 
									Systems</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Ex-rated 
									Environments</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Flame Proof 
									Stores</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Chemical 
									Stores</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Hazardous 
									Locations</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Reticulations 
									(development)</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Consulting 
									On Your Requirements</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Cable Faults 
									And Tracing</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Networking 
									Sulotions</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Server Rooms &amp; 
									Safes</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Pump Stations</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Planing And 
									Design</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Identification 
									Labeling</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Agricultural 
									Support</span><br class="auto-style5">
									<span class="auto-style5">&nbsp; • Out-of-province 
									Support</span></p>
									<h2><span class="auto-style5">
									<img alt="Industrial Electrical Services Gauteng" height="17" src="ind_head.jpg" width="151"></span></h2>
									<p class="auto-style4">
									<span class="auto-style5">&nbsp; • Reticulations<br>&nbsp; 
									• Design<br>&nbsp; • Planning<br>&nbsp; • Construction<br>&nbsp; 
									• Development<br>&nbsp; • Maintenance<br>&nbsp; 
									• Subs &amp; Mini Subs<br>&nbsp; • LV &amp; 
									MV<br>&nbsp; • Wiring &amp; Cabling<br>&nbsp; 
									• Spares &amp; Repairs<br>&nbsp; • Agricultural<br>&nbsp; 
									• Contracts</span></p>
									</td>
									<td style="width: 20">&nbsp;</td>
								</tr>
								<tr>
									<td style="width: 20">&nbsp;</td>
									<td class="auto-style7" colspan="3" valign="top">
									<img alt="Electrician Gauteng" class="auto-style9" height="122" src="v1.jpg" width="180">&nbsp;&nbsp;
									<img alt="Electrical wiring contractor" class="auto-style9" height="122" src="v2.jpg" width="180">&nbsp;&nbsp;
									<img alt="Electrical Services" class="auto-style9" height="122" src="v3.jpg" width="180"></td>
									<td style="width: 20">&nbsp;</td>
								</tr>
								<tr>
									<td style="width: 20">&nbsp;</td>
									<td style="width: 282" valign="top">&nbsp;</td>
									<td style="width: 20" valign="top">&nbsp;</td>
									<td style="width: 282" valign="top">&nbsp;</td>
									<td style="width: 20">&nbsp;</td>
								</tr>
								<tr>
									<td style="width: 20">&nbsp;</td>
									<td class="auto-style5" colspan="3" valign="top">
									<a name="blog">
									<img height="24" src="blog_head.jpg" width="55"></a><br>
									This Blog is under construction. Please check 
									back regularly for more updates on our progress.<br>&nbsp;</td>
									<td style="width: 20">&nbsp;</td>
								</tr>
							</table>
							</td>
						</tr>
						<tr>
							<td>
							<img height="24" src="line.jpg" width="624"></td>
						</tr>
						<tr>
							<td class="auto-style2" valign="top">
							<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
								<tr>
									<td style="width: 20">&nbsp;</td>
									<td>
									<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
										<tr>
											<td style="width: 282" valign="top">
											<p class="auto-style4"><br>
											<a name="contact">
											<img align="top" alt="Contact Voltman Electrical" height="17" src="cont_head.jpg" width="86"></a><span class="auto-style11"><strong><br>&nbsp; 
											Address:</strong></span><br class="auto-style10">
											<span class="auto-style10">&nbsp; P.O. 
											Box 11351, Aston Manor, 1630</span><br class="auto-style10">
											<span class="auto-style11"><strong>&nbsp; 
											Contact Details: </strong></span>
											<br class="auto-style10">
											<span class="auto-style10">&nbsp; Mobile: 
											073 400 2539</span><br class="auto-style10">
											<span class="auto-style10">&nbsp; Fax: 
											086 608 2539</span><br class="auto-style10">
											<span class="auto-style10">&nbsp; Email:
											<a class="auto-style14" href="mailto:admin@voltman.co.za">
											<span class="auto-style15">admin@voltman.co.za</span></a>
											</span></p>
											</td>
											<td style="width: 20" valign="top">&nbsp;</td>
											<td style="width: 282" valign="top">
											<form action="index.php" method="post">
												<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
													<tr>
														<td><br>
														<img alt="online enquiries for electrical services" height="17" src="online_head.jpg" width="129"><br>&nbsp;</td>
													</tr>
													<tr>
														<td>
														<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
															<tr>
																<td class="auto-style12" style="width: 82px">
																Name:</td>
																<td>&nbsp;&nbsp;
																<input name="name" style="width: 185px" type="text"></td>
															</tr>
															<tr>
																<td class="auto-style12" style="width: 82px">
																Email:</td>
																<td>&nbsp;&nbsp;
																<input name="email" style="width: 185px" type="text"></td>
															</tr>
															<tr>
																<td class="auto-style12" style="width: 82px">
																Message:</td>
																<td>&nbsp;&nbsp;
																<textarea name="message" style="width: 185px; height: 58px"></textarea></td>
															</tr>
															<tr>
																<td class="auto-style12" style="width: 82px">&nbsp;</td>
																<td class="auto-style7">
																<input style="width: 73px" type="submit" value="Send"></td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</form>
											</td>
										</tr>
									</table>
									</td>
									<td style="width: 20">&nbsp;</td>
								</tr>
							</table>
							</td>
						</tr>
					</table>
					</td>
					<td class="auto-style3" style="width: 320" valign="top">
					<table cellpadding="0" cellspacing="0" class="style1" style="width: 100%">
						<tr>
							<td style="width: 30">&nbsp;</td>
							<td>
							<h1><span class="auto-style10"><br>
							<img alt="Proffessional Electrical Contractor Gauteng" height="37" src="elec_head.jpg" width="116"></span></h1>
							<p class="auto-style4"><span class="auto-style11">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Electrical Repairs<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Cables<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Geysers<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Plugs Lights<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• C.O.C.&#39;s<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Main Switches<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Circuit Breakers<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Motors<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Pool Pumps<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Jacuzzi&#39;s<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• BD-Boards<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Faults &amp; Maintenance.</span><br class="auto-style10">
							</p>
							<h1>&nbsp;<br>
							<img alt="Electrical contractor in kempton park, pretoria, midrand, east rand, randburg, sandton and kyalami" height="37" src="serv_head.jpg" width="116"></h1>
							<p class="auto-style4"><span class="auto-style11">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Kempton Park<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Isando<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Spartan<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Jet Park Boksburg<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Bredell<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Petit<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Centurion<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• PTA Benoni<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Edenvale<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Midrand <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Dainfern<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Kyalami</span><br class="auto-style11">
							<span class="auto-style11">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Woodmead<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Meyerton<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							• Alberton.</span><br></p>
							<h2><br class="auto-style10">
							<img alt="Industrial and Domestic Electrical Contractors" height="37" src="inddom_head.jpg" width="213"><br class="auto-style10">
							</h2>
							<p class="auto-style4"><span class="auto-style10">Please 
							NOTE that safety is of the utmost importance &amp; NO 
							risks will be entered into. Regulations are KEY in our 
							Business. <br><br>Full Site INDUCTIONS will be adhered 
							to. Certificates and Authorisations where needed.
							<br><br><br><br><br>&nbsp;</span></p>
							</td>
							<td style="width: 30">&nbsp;</td>
						</tr>
						<tr>
							<td class="auto-style7" colspan="3">
							<img alt="Voltman Electrical Contractors Gauteng" height="77" src="logo_small.jpg" width="290"></td>
						</tr>
					</table>
					</td>
					<td class="auto-style1">&nbsp;</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td><img height="22" src="footer.png" width="962"></td>
		</tr>
	</table>
</div>
<p class="auto-style7">

<head>
</head>
</body>

</html>
